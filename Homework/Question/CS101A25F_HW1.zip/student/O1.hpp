#pragma once
#include <iostream>
// Do NOT use `using namespace std;` globally.
// Fill in each function body where marked TODO.

// O.1 — Very short placeholder (students implement full demo).
inline void o1_print_bridge_invalidation() {
    // TODO: implement per spec (mutate via pointer, grow until reallocation, print results)
    std::cout << "================ [O1] Array <-> Vector Bridge & Pointer Invalidation ================\n";
    std::cout << "[O.1] TODO\n";
}
