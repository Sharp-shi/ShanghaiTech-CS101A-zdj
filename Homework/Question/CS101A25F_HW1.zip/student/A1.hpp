#pragma once
// Do NOT use `using namespace std;` globally.
// Fill in each function body where marked TODO.

// A.1 — Count strictly positive values in [p, p+N) using POINTER arithmetic only.
inline int count_positive(const int* p, int N) {
    // TODO: implement pointer-only scan
    (void)p; (void)N;
    return 0;
}

// A.1 — Reverse [p, p+N) in place using POINTER arithmetic only.
inline void reverse_inplace(int* p, int N) {
    // TODO: implement in-place reverse using two pointers
    (void)p; (void)N;
    // no-op skeleton
}