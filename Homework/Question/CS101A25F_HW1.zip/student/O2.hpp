#pragma once
#include <iostream>
// Do NOT use `using namespace std;` globally.
// Fill in each function body where marked TODO.

// O.2 — Short placeholder text (students write 2–4 sentences).
inline void o2_print_api_design_reflection() {
    // TODO: print a brief paragraph about pointer vs reference API design
    std::cout << "[O.2] TODO\n";
}