#include "pvz/GameWorld/GameWorld.hpp"
#include "pvz/GameObject/GameObject.hpp"

#include "pvz/utils.hpp"
#include <vector>
#include <set>

bool GameWorld::IsZombieOnRowRight(int y, int x) const {
	for (auto &obj : mlist) {
		if (obj->isZombie()) {
			if (obj->GetX() > x) {
				if (std::abs(obj->GetY() - y) <= obj->GetHeight() /2) return true;
			}
		}
	}
	return false;
}

void GameWorld::DamageZombiesInRadius(int cx, int cy, int radius, int damage) {
	int rr = radius * radius;
	for (auto &obj : mlist) {
		if (!obj) continue;
		if (obj->isZombie()) {
			int dx = obj->GetX() - cx;
			int dy = obj->GetY() - cy;
			if (dx*dx + dy*dy <= rr) obj->SetHP(obj->GetHP() - damage);
		}
	}
}

pGameObject GameWorld::GetPlantAtRect(int x, int y, int width, int height) const {
	for (auto &obj : mlist) {
		if (!obj) continue;
		if (!obj->isPlant()) continue;
		int dx = std::abs(obj->GetX() - x);
		int dy = std::abs(obj->GetY() - y);
		if (dx *2 <= (obj->GetWidth() + width) && dy *2 <= (obj->GetHeight() + height)) return obj;
	}
	return nullptr;
}

void GameWorld::Init(){
	//��ʼ����Դ
	m_SunCount =50;
	m_WaveCount =0;
	m_SunDropCD =180;
	m_nextZombieTick =1200;

	mlist.clear();
	//����
	auto pbackground = std::make_shared<Background>();
	Add(pbackground);

	//���� 
	auto sunflowerSeed = std::make_shared<Seed>(ImageID::SEED_SUNFLOWER,130, WINDOW_HEIGHT - 44, shared_from_this());
	Add(sunflowerSeed);
	auto peashooterSeed = std::make_shared<Seed>(ImageID::SEED_PEASHOOTER,190, WINDOW_HEIGHT - 44, shared_from_this());
	Add(peashooterSeed);
	auto wallnutSeed = std::make_shared<Seed>(ImageID::SEED_WALLNUT,250, WINDOW_HEIGHT - 44, shared_from_this());
	Add(wallnutSeed);
	auto cherrySeed = std::make_shared<Seed>(ImageID::SEED_CHERRY_BOMB,310, WINDOW_HEIGHT - 44, shared_from_this());
	Add(cherrySeed);
	auto repeaterSeed = std::make_shared<Seed>(ImageID::SEED_REPEATER,370, WINDOW_HEIGHT - 44, shared_from_this());
	Add(repeaterSeed);

	//����
	auto shovelBtn = std::make_shared<Shovel>(600, WINDOW_HEIGHT -40, shared_from_this());
	Add(shovelBtn);

	m_sunText = std::make_shared<TextBase>(60, WINDOW_HEIGHT -78, std::to_string(GetSunCount()));
	m_sunText->SetColor(1,1,0);
	m_sunText->SetCentering(false);

	m_waveText = std::make_shared<TextBase>(WINDOW_WIDTH -160,8, std::to_string(GetWaveCount()));
	m_waveText->SetColor(1,1,0);
	m_waveText->SetCentering(false);

	//��ֲ��
	for (int row =0; row < 5; ++row) {
		for (int col =0; col < 9; ++col) {
			int x = 75 + col * 80;
			int y = 75 + row * 100;
			auto spot = std::make_shared<PlantingSpot>(x, y, shared_from_this());
			Add(spot);
		}
	}
}

LevelStatus GameWorld::Update() {
	if (m_SunDropCD ==0) {
		GenerateSun();
		m_SunDropCD =300; 
	}
	m_SunDropCD--;

	//���ɽ�ʬ
	if (m_nextZombieTick ==0){
		int wave = ++ m_WaveCount;
		int numZombies = floor((15 + wave) /10); // floor
		for (int i =1; i <= numZombies; i++) {
			int P1 =20, P2 = 2 * std::max(wave - 8, 0), P3 = 3 * std::max(wave - 15, 0);
			int sum = P1 + P2 + P3, pick = randInt(1, sum);
			int row = randInt(0, GAME_ROWS -1);
			int zx = randInt(WINDOW_WIDTH -40, WINDOW_WIDTH -1), zy = FIRST_ROW_CENTER + row * LAWN_GRID_HEIGHT;
			if (pick <= P1) {
				auto zombie = std::make_shared<RegularZombie>(zx, zy);
				Add(zombie);
			} else if (pick <= P1 + P2) {
				auto zombie = std::make_shared<PoleVaultingZombie>(zx, zy);
				Add(zombie);
			} else {
				auto zombie = std::make_shared<BucketHeadZombie>(zx, zy);
				Add(zombie);
			}
		}
		int nextCd = std::max(150,600 -20 * wave);
		m_nextZombieTick = nextCd;
	}
	m_nextZombieTick--;

	// ˢ��
	for (auto &obj : mlist) {
		if (obj) obj->Update();
	}

	// ����
	for (auto &obj : mlist) {
		if (obj) obj->ProbeForward(this);
	}

	// ��ײ���
	for (auto &a : mlist) {
		if (!a) continue;
		if (a->isProjectile()) {
			for (auto &b : mlist) {
				if (!b) continue;
				if (!b->isZombie()) continue;
				int dx = std::abs(a->GetX() - b->GetX());
				int dy = std::abs(a->GetY() - b->GetY());
				if (dx *2 <= (a->GetWidth() + b->GetWidth()) && dy *2 <= (a->GetHeight() + b->GetHeight())) {
					b->SetHP(b->GetHP() -20);
					a->SetHP(0);
				}
			}
		}

		if (a->isZombie()) {
			for (auto &b : mlist) {
				if (!b) continue;
				if (!b->isPlant()) continue;
				int dx = std::abs(a->GetX() - b->GetX());
				int dy = std::abs(a->GetY() - b->GetY());
				if (dx *2 <= (a->GetWidth() + b->GetWidth()) && dy *2 <= (a->GetHeight() + b->GetHeight())) {
					a->OnCollideWithPlant(b.get());
				}
			}
		}
	}

	// �ƾ�
	for (auto it = mlist.begin(); it != mlist.end(); ) {
		if ((*it)->GetHP() <=0) {
		it = mlist.erase(it);
	} else {
		++it;
		}
	}

	//������
	for (auto &obj : mlist) {
		if (obj->isZombie()) {
			obj->ValidateEatingTarget(mlist);
		}
	}

	// ���ʧ��
	for (auto &obj : mlist) {
		if (obj->isZombie()) {
			if (obj->GetX() <0) {
				m_resultText = std::make_shared<TextBase>(330,50, std::to_string(GetWaveCount()));
				m_resultText->SetColor(1,1,1);
				m_resultText->SetCentering(false);
				return LevelStatus::LOSING;
			}
		}
	}

	if (m_sunText) m_sunText->SetText(std::to_string(GetSunCount()));
	if (m_waveText) m_waveText->SetText(std::to_string(GetWaveCount()));

	return LevelStatus::ONGOING;
}

void GameWorld::CleanUp() {
	if (m_sunText) m_sunText.reset();
	if (m_waveText) m_waveText.reset();
	if (m_resultText) m_resultText.reset();
	mlist.clear();
}

/// @brief�����µ�����
void GameWorld::GenerateSun(){
	int x = randInt(75, WINDOW_WIDTH -75);
	int y = WINDOW_HEIGHT -1;
	auto sun = std::make_shared<Sun>(x, y, true, shared_from_this());
	Add(sun);
}