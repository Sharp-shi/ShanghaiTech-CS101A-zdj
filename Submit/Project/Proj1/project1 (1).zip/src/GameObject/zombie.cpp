#include "pvz/GameObject/zombie.hpp"
#include "pvz/GameWorld/GameWorld.hpp"

RegularZombie::RegularZombie(int x, int y) 
    : Zombie(ImageID::REGULAR_ZOMBIE, x, y, 200) {}

void RegularZombie::Update() {
    if (GetHP() <= 0) return;
    if (m_state == State::EATING) {
        HandleEatingState();
        return;
    }
    MoveTo(GetX() - 1, GetY());
}

BucketHeadZombie::BucketHeadZombie(int x, int y) 
    : Zombie(ImageID::BUCKET_HEAD_ZOMBIE, x, y, 1300), m_bucketOn(true) {}

void BucketHeadZombie::Update() {
    if (GetHP() <= 0) return;
    if (m_bucketOn && GetHP() <= 200) {
        m_bucketOn = false;
        ChangeImage(ImageID::REGULAR_ZOMBIE);
    }
    if (m_state == State::EATING) {
        HandleEatingState();
        return;
    }
    MoveTo(GetX() - 1, GetY());
}

PoleVaultingZombie::PoleVaultingZombie(int x, int y) 
    : Zombie(ImageID::POLE_VAULTING_ZOMBIE, x, y, 340), 
    m_pvState(PVState::RUNNING), m_timer(0) {
    PlayAnimation(AnimID::RUN);
}

void PoleVaultingZombie::Update() {
    if (GetHP() <= 0) return;
    switch (m_pvState) {
    case PVState::RUNNING:
        MoveTo(GetX() - 2, GetY());
        break;
    case PVState::JUMPING:
        if (m_timer > 0) m_timer--; 
        else {
            MoveTo(GetX() - 150, GetY());
            m_pvState = PVState::WALKING;
            m_state = State::WALKING;
            PlayAnimation(AnimID::WALK);
        }
        break;
    case PVState::WALKING:
        MoveTo(GetX() - 1, GetY());
        break;
    case PVState::EATING:
        HandleEatingState();
        if (m_state == State::WALKING) {
            m_pvState = PVState::WALKING;
        }
        break;
    }
}

void PoleVaultingZombie::OnCollideWithPlant(GameObject* plant) {
    if (!plant) return;
    if (m_pvState == PVState::RUNNING) {
        m_pvState = PVState::JUMPING;
        PlayAnimation(AnimID::JUMP);
        m_timer = 42;
    } else if (m_pvState == PVState::WALKING) {
        m_pvState = PVState::EATING;
        m_state = State::EATING;
        m_target = plant;
        PlayAnimation(AnimID::EAT);
    }
}

void PoleVaultingZombie::ValidateEatingTarget(const GameList<pGameObject>& worldList) {
    if (m_pvState != PVState::EATING) return;
    bool found = false;
    for (auto &o : worldList) {
        if (o.get() == m_target) { 
            found = true; 
            break; 
        }
    }
    if (!found) {
        m_pvState = PVState::WALKING;
        m_state = State::WALKING;
        PlayAnimation(AnimID::WALK);
        m_target = nullptr;
    }
}

void PoleVaultingZombie::ProbeForward(GameWorld* world) {
    if (m_pvState != PVState::RUNNING) return;
    if (!world) return;
    int probeX = GetX() - 40;
    auto plant = world->GetPlantAtRect(probeX, GetY(), GetWidth(), GetHeight());
    if (plant) OnCollideWithPlant(plant.get());
}
