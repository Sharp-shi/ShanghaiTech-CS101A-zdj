#include "pvz/GameObject/GameObject.hpp"
#include "pvz/GameWorld/GameWorld.hpp"
#include "pvz/GameObject/plant.hpp"

// Your everything begins from here.

#include "pvz/utils.hpp" // ������õ��� randInt

void Seed::Update() {
    if (m_cooldownRemaining >0) m_cooldownRemaining--;
}

void Seed::OnClick() {
    if (!m_world) return;
    if (m_world->GetMouseState() == mouse_state::M_SHOVEL) return;
    if (m_world->GetMouseState() == mouse_state::M_SEED) return;

    if (m_cooldownRemaining >0) return;

    if (m_world->GetSunCount() < m_price) return;

    m_world->ChangeSun(-m_price);

    m_cooldownRemaining = m_cooldownTicks;

    auto mask = std::make_shared<CooldownMask>(GetX(), GetY(), m_cooldownTicks);
    m_world->Add(mask);

    m_world->SetMouseState(mouse_state::M_SEED);
    m_world->SetSelectedSeed(m_plantImage);
}

void PlantingSpot::OnClick() {
    if (!m_world) return;
    if (m_world->GetMouseState() != mouse_state::M_SEED) return;
    ImageID selfI = m_world->GetSelectedSeed();
    if (selfI == ImageID::NONE) return;

    int x = GetX();
    int y = GetY();
    pGameObject plantp = nullptr;
    switch (selfI) {
        case ImageID::SUNFLOWER:
            plantp = std::make_shared<Sunflower>(x, y, m_world);
            break;
        case ImageID::PEASHOOTER:
            plantp = std::make_shared<Peashooter>(x, y, m_world);
            break;
        case ImageID::WALLNUT:
            plantp = std::make_shared<Wallnut>(x, y, m_world);
            break;
        case ImageID::CHERRY_BOMB:
            plantp = std::make_shared<CherryBomb>(x, y, m_world);
            break;
        case ImageID::REPEATER:
            plantp = std::make_shared<Repeater>(x, y, m_world);
            break;
        default:
            break;
    }

    if (plantp) {
        m_world->Add(plantp);
        m_world->SetMouseState(mouse_state::M_NONE);
        m_world->SetSelectedSeed(ImageID::NONE);
    }
}
