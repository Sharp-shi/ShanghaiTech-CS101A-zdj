#include "pvz/GameObject/GameObject.hpp"
#include "pvz/GameObject/plant.hpp"
#include "pvz/GameWorld/GameWorld.hpp"
#include "pvz/utils.hpp"

Sun::Sun(int x, int y, bool sky, pGameWorld world)
    : GameObject(ImageID::SUN, x, y, LayerID::SUN, 80, 80, AnimID::IDLE, 1),
      isfromsky(sky),
      gameworld(world),
      lifetime(300)
{
    if (isfromsky){
        droptime = randInt(63, 263);
        m_landingY = (WINDOW_HEIGHT - 1) - droptime * 2;
        m_verticalSpeed = 0;
    }
    else{
        droptime = 12;
        m_landingY = y;
        m_verticalSpeed = 4;
    }
}

void Sun::Update(){
    if (droptime > 0){
        if (isfromsky) MoveTo(GetX(), GetY() - 2);
        else MoveTo(GetX() - 1, GetY() + droptime - 8);
        droptime--;
    }
    else{
        if (lifetime > 0) lifetime--;
        else if (lifetime == 0) HP = 0;
    }
}

void Sun::OnClick(){
    HP = 0;
    gameworld->ChangeSun(25);
}

Sunflower::Sunflower(int x, int y, pGameWorld world)
    : Plant(ImageID::SUNFLOWER, x, y, AnimID::IDLE, 300), m_world(world){
    m_nextProduce = randInt(30, 600);
    m_interval = 600;
}

void Sunflower::Update(){
    if (GetHP() <= 0) return;
    if (m_nextProduce <= 0){
        auto s = std::make_shared<Sun>(GetX(), GetY(), false, m_world);
        m_world->Add(s);
        m_nextProduce = m_interval;
    }
    else m_nextProduce--;
}

void Sunflower::OnClick(){
    if (!m_world) return;
    if (m_world->GetMouseState() == mouse_state::M_SHOVEL){
        SetHP(0);
        m_world->SetMouseState(mouse_state::M_NONE);
    }
}


Pea::Pea(int x, int y)
    : GameObject(ImageID::PEA, x, y, LayerID::PROJECTILES, 28, 28, AnimID::NO_ANIMATION, 1)
{}

void Pea::Update(){
    if (GetHP() <= 0) return;
    MoveTo(GetX() + 8, GetY());
    if (GetX() > WINDOW_WIDTH) HP = 0;
}


Peashooter::Peashooter(int x, int y, pGameWorld world)
    : Plant(ImageID::PEASHOOTER, x, y, AnimID::IDLE, 300), m_world(world), m_cooldown(0), m_interval(30)
{}

void Peashooter::Update(){
    if (GetHP() <= 0) return;
    if (m_cooldown > 0) { --m_cooldown; return; }
    if (!m_world) return;
    if (m_world->IsZombieOnRowRight(GetY(), GetX())){
        int px = GetX() + 30;
        int py = GetY() + 20;
        auto pea = std::make_shared<Pea>(px, py);
        m_world->Add(pea);
        m_cooldown = m_interval;
    }
}

void Peashooter::OnClick(){
    if (!m_world) return;
    if (m_world->GetMouseState() == mouse_state::M_SHOVEL){
        SetHP(0);
        m_world->SetMouseState(mouse_state::M_NONE);
    }
}


Wallnut::Wallnut(int x, int y, pGameWorld world)
    : Plant(ImageID::WALLNUT, x, y, AnimID::IDLE, 4000), m_world(world), m_maxHP(4000)
{}

void Wallnut::Update(){
    if (GetHP() <= 0) return;
    if (GetHP() < m_maxHP / 3) ChangeImage(ImageID::WALLNUT_CRACKED);
}

void Wallnut::OnClick(){
    if (!m_world) return;
    if (m_world->GetMouseState() == mouse_state::M_SHOVEL){
        SetHP(0);
        m_world->SetMouseState(mouse_state::M_NONE);
    }
}


Explosion::Explosion(int x, int y, pGameWorld world)
    : GameObject(ImageID::EXPLOSION, x, y, LayerID::PROJECTILES, 3 * LAWN_GRID_WIDTH, 3 * LAWN_GRID_HEIGHT, AnimID::NO_ANIMATION, 1), m_world(world), m_life(3)
{}

void Explosion::Update(){
    if (GetHP() <= 0) return;
    if (m_world){
        int radius = std::max(GetWidth(), GetHeight()) / 2;
        m_world->DamageZombiesInRadius(GetX(), GetY(), radius, 9999);
    }
    m_life--;
    if (m_life <= 0) HP = 0;
}


CherryBomb::CherryBomb(int x, int y, pGameWorld world)
    : Plant(ImageID::CHERRY_BOMB, x, y, AnimID::IDLE, 4000), m_world(world), m_timer(15)
{}

void CherryBomb::Update(){
    if (GetHP() <= 0) return;
    if (m_timer > 0) { --m_timer; return; }
    if (m_world){
        m_world->DamageZombiesInRadius(GetX(), GetY(), 120, 200);
        auto explosion = std::make_shared<Explosion>(GetX(), GetY(), m_world);
        m_world->Add(explosion);
    }
    HP = 0;
}

void CherryBomb::OnClick(){
    if (!m_world) return;
    if (m_world->GetMouseState() == mouse_state::M_SHOVEL){
        SetHP(0);
        m_world->SetMouseState(mouse_state::M_NONE);
    }
}


Repeater::Repeater(int x, int y, pGameWorld world)
    : Plant(ImageID::REPEATER, x, y, AnimID::IDLE, 300), m_world(world), m_cooldown(0), m_secondDelay(-1), m_interval(30)
{}

void Repeater::Update(){
    if (GetHP() <= 0) return;
    if (m_cooldown > 0){
        m_cooldown--;
        if (m_secondDelay > 0){
            m_secondDelay--;
            if (m_secondDelay == 0 && m_world){
                int px = GetX() + 30;
                int py = GetY() + 20;
                auto pea = std::make_shared<Pea>(px, py);
                m_world->Add(pea);
                m_secondDelay = -1;
            }
        }
        return;
    }

    if (!m_world) return;
    if (m_world->IsZombieOnRowRight(GetY(), GetX())){
        int px = GetX() + 30;
        int py = GetY() + 20;
        auto pea = std::make_shared<Pea>(px, py);
        m_world->Add(pea);
        m_cooldown = m_interval;
        m_secondDelay = 5;
    }
}

void Repeater::OnClick()
{
    if (!m_world) return;
    if (m_world->GetMouseState() == mouse_state::M_SHOVEL){
        SetHP(0);
        m_world->SetMouseState(mouse_state::M_NONE);
    }
}


Shovel::Shovel(int x, int y, pGameWorld world)
    : GameObject(ImageID::SHOVEL, x, y, LayerID::UI, 50, 50, AnimID::NO_ANIMATION, 1), m_world(world)
{}

void Shovel::OnClick(){
    if (!m_world) return;
    if (m_world->GetMouseState() == mouse_state::M_SEED) return;
    if (m_world->GetMouseState() == mouse_state::M_SHOVEL) m_world->SetMouseState(mouse_state::M_NONE);
    else{
        m_world->SetMouseState(mouse_state::M_SHOVEL);
        m_world->SetSelectedSeed(ImageID::NONE);
    }
}
