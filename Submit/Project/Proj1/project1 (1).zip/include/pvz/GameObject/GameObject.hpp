#ifndef GAMEOBJECT_HPP__
#define GAMEOBJECT_HPP__

#include "pvz/Framework/ObjectBase.hpp"
#include "pvz/Containers/GameList.hpp"
#include <memory>
#include "pvz/GameObject/plant.hpp"
#include "pvz/GameObject/zombie.hpp"

template<typename T> class GameList;
class GameWorld;
using pGameWorld = std::shared_ptr<GameWorld>;
using pGameObject = std::shared_ptr<class GameObject>;

class GameObject : public ObjectBase, public std::enable_shared_from_this<GameObject> {
public:
	GameObject(ImageID imageID, int x, int y, LayerID layer, int width, int height, AnimID animID, int hp)
		: ObjectBase(imageID, x, y, layer, width, height, animID), HP(hp)
	{}

	virtual bool isPlant() const = 0;
	virtual bool isZombie() const = 0;
	virtual bool isSeed() const = 0;
	virtual bool isProjectile() const = 0;
	virtual void Update() {}
	virtual void OnClick() {}
	virtual void OnCollideWithPlant(GameObject* plant) {}
	virtual void ValidateEatingTarget(const GameList<pGameObject>& worldList) {}
	virtual void ProbeForward(class GameWorld* world) {}  // For PoleVaultingZombie probing

	void SetHP(int hp) { HP = hp; }
	int GetHP() const { return HP; }

	using std::enable_shared_from_this<GameObject>::shared_from_this;

protected:
	int HP = 0;
};

/// @brief 背景
class Background : public GameObject{
public:
	Background():
	GameObject(ImageID::BACKGROUND, WINDOW_WIDTH /2, WINDOW_HEIGHT /2, LayerID::BACKGROUND, WINDOW_WIDTH, WINDOW_HEIGHT, AnimID::NO_ANIMATION,1)
	{}

	void Update() override {}
	void OnClick() override {}

	bool isPlant() const override {return false;}
	bool isZombie() const override {return false;}
	bool isSeed() const override {return false;}
	bool isProjectile() const override {return false;}
};

/// @brief PlantingSpot
class PlantingSpot : public GameObject{
public:
	PlantingSpot(int x, int y, pGameWorld world):
	GameObject(ImageID::NONE, x, y, LayerID::UI,60,80, AnimID::NO_ANIMATION,1), m_world(world)
	{}

	void Update() override {}
	void OnClick() override;

	bool isPlant() const override {return false;}
	bool isZombie() const override {return false;}
	bool isSeed() const override {return false;}
	bool isProjectile() const override {return false;}
private:
	pGameWorld m_world;
};

class Seed : public GameObject{
public:
	Seed(ImageID imageID, int x, int y, pGameWorld world):
	GameObject(imageID, x, y, LayerID::UI,50,70, AnimID::NO_ANIMATION,1), m_world(world), m_seedImage(imageID), m_plantImage(ImageID::NONE), m_price(0), m_cooldownTicks(0), m_cooldownRemaining(0){
	switch (m_seedImage) {
	case ImageID::SEED_SUNFLOWER:
		m_price =50;
		m_cooldownTicks =240;
		m_plantImage = ImageID::SUNFLOWER;
		break;
	case ImageID::SEED_PEASHOOTER:
		m_price =100;
		m_cooldownTicks =240;
		m_plantImage = ImageID::PEASHOOTER;
		break;
	case ImageID::SEED_WALLNUT:
		m_price =50;
		m_cooldownTicks =900; 
		m_plantImage = ImageID::WALLNUT;
		break;
	case ImageID::SEED_CHERRY_BOMB:
		m_price =150;
		m_cooldownTicks =1200; 
		m_plantImage = ImageID::CHERRY_BOMB;
		break;
	case ImageID::SEED_REPEATER:
		m_price =200;
		m_cooldownTicks =240;
		m_plantImage = ImageID::REPEATER;
		break;
	default:
		m_price =50;
		m_cooldownTicks =240;
		m_plantImage = ImageID::NONE;
		break;
	}
}

void Update() override;
void OnClick() override;

bool isPlant() const override { return false; }
bool isZombie() const override { return false; }
bool isSeed() const override { return true; }
bool isProjectile() const override { return false; }

private:
	pGameWorld m_world;
	ImageID m_seedImage;
	ImageID m_plantImage;
	int m_price;
	int m_cooldownTicks;
	int m_cooldownRemaining;
};

class CooldownMask : public GameObject {
public:
	CooldownMask(int x, int y, int lifetimeTicks) :
	GameObject(ImageID::COOLDOWN_MASK, x, y, LayerID::COOLDOWN_MASK,50,70, AnimID::NO_ANIMATION,1), m_life(lifetimeTicks) {}
	void Update() override {
		if (m_life >0) m_life--; 
		else HP =0;
	}
	void OnClick() override {}
	bool isPlant() const override { return false; }
	bool isZombie() const override { return false; }
	bool isSeed() const override { return false; }
	bool isProjectile() const override { return false; }

private:
	int m_life;
};

class sun :public GameObject{
public:
	sun(ImageID imageID, int x, int y, int hp) :
	GameObject(imageID, x, y, LayerID::SUN,50,50, AnimID::IDLE, hp)
	{}

	void Update() override {}
	void OnClick() override {}
	bool isPlant() const override { return false; }
	bool isZombie() const override { return false; }
	bool isSeed() const override { return false; }
	bool isProjectile() const override { return false; }
};

#endif