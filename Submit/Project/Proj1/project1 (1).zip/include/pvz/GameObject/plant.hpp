#ifndef PLANT_HPP__
#define PLANT_HPP__

#include "pvz/GameObject/GameObject.hpp"

class GameWorld;
using pGameWorld = std::shared_ptr<class GameWorld>;

class Plant : public GameObject {
public:
    Plant(ImageID imageID, int x, int y, AnimID animID, int hp)
        : GameObject(imageID, x, y, LayerID::PLANTS, 60, 80, animID, hp) {}

    void Update() override {}
    void OnClick() override {}
    bool isPlant() const override { return true; }
    bool isZombie() const override { return false; }
    bool isSeed() const override { return false; }
    bool isProjectile() const override { return false; }
};

class Sun : public GameObject {
public:
    Sun(int x, int y, bool sky, pGameWorld world);
    void Update() override;
    void OnClick() override;
    bool isPlant() const override { return false; }
    bool isZombie() const override { return false; }
    bool isSeed() const override { return false; }
    bool isProjectile() const override { return false; }
private:
    bool isfromsky;
    pGameWorld gameworld;
    int droptime;
    int lifetime;
    int m_landingY;
    int m_verticalSpeed;
};

class Sunflower : public Plant {
public:
    Sunflower(int x, int y, pGameWorld world);
    void Update() override;
    void OnClick() override;
private:
    pGameWorld m_world;
    int m_nextProduce;
    int m_interval;
};

class Pea : public GameObject {
public:
    Pea(int x, int y);
    void Update() override;
    void OnClick() override {}
    bool isPlant() const override { return false; }
    bool isZombie() const override { return false; }
    bool isSeed() const override { return false; }
    bool isProjectile() const override { return true; }
};

class Peashooter : public Plant {
public:
    Peashooter(int x, int y, pGameWorld world);
    void Update() override;
    void OnClick() override;
private:
    pGameWorld m_world;
    int m_cooldown;
    int m_interval;
};

class Wallnut : public Plant {
public:
    Wallnut(int x, int y, pGameWorld world);
    void Update() override;
    void OnClick() override;
private:
    pGameWorld m_world;
    int m_maxHP;
};

class Explosion : public GameObject {
public:
    Explosion(int x, int y, pGameWorld world);
    void Update() override;
    void OnClick() override {}
    bool isPlant() const override { return false; }
    bool isZombie() const override { return false; }
    bool isSeed() const override { return false; }
    bool isProjectile() const override { return false; }
private:
    pGameWorld m_world;
    int m_life;
};

class CherryBomb : public Plant {
public:
    CherryBomb(int x, int y, pGameWorld world);
    void Update() override;
    void OnClick() override;
private:
    pGameWorld m_world;
    int m_timer;
};

class Repeater : public Plant {
public:
    Repeater(int x, int y, pGameWorld world);
    void Update() override;
    void OnClick() override;
private:
    pGameWorld m_world;
    int m_cooldown;
    int m_secondDelay;
    int m_interval;
};

class Shovel : public GameObject {
public:
    Shovel(int x, int y, pGameWorld world);
    void Update() override {}
    void OnClick() override;
    bool isPlant() const override { return false; }
    bool isZombie() const override { return false; }
    bool isSeed() const override { return false; }
    bool isProjectile() const override { return false; }
private:
    pGameWorld m_world;
};

#endif // PLANT_HPP__
