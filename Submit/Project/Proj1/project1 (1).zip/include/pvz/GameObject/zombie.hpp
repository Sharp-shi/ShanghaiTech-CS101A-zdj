#ifndef ZOMBIE_HPP__
#define ZOMBIE_HPP__

#include "pvz/GameObject/GameObject.hpp"
#include "pvz/Containers/GameList.hpp"

class GameWorld;

class Zombie : public GameObject {
public:
    enum class State {WALKING, EATING};
    
    Zombie(ImageID imageID, int x, int y, int hp)
        : GameObject(imageID, x, y, LayerID::ZOMBIES, 20, 80, AnimID::WALK, hp), 
          m_state(State::WALKING), m_target(nullptr) {}

    void Update() override {}
    void OnClick() override {}
    bool isPlant() const override { return false; }
    bool isZombie() const override { return true; }
    bool isSeed() const override { return false; }
    bool isProjectile() const override { return false; }
    
    void ValidateEatingTarget(const GameList<pGameObject>& worldList) override {
        if (m_state != State::EATING) return;
        bool found = false;
        for (auto &o : worldList) {
            if (o.get() == m_target) { 
            found = true; 
                break; 
     }
     }
        if (!found) {
    m_state = State::WALKING;
            PlayAnimation(AnimID::WALK);
            m_target = nullptr;
        }
    }

    void OnCollideWithPlant(GameObject* plant) override {
if (!plant) return;
      if (m_state == State::WALKING) {
    m_state = State::EATING;
 m_target = plant;
   PlayAnimation(AnimID::EAT);
        }
    }

protected:
void HandleEatingState() {
        if (m_target && m_target->GetHP() > 0) {
          m_target->SetHP(m_target->GetHP() - 3);
 } else {
  m_state = State::WALKING;
            PlayAnimation(AnimID::WALK);
            m_target = nullptr;
 }
    }
    
    State m_state;
    GameObject* m_target;
};


class RegularZombie : public Zombie {
public:
    RegularZombie(int x, int y);
    void Update() override;
};


class BucketHeadZombie : public Zombie {
public:
    BucketHeadZombie(int x, int y);
  void Update() override;

private:
    bool m_bucketOn;
};


class PoleVaultingZombie : public Zombie {
public:
    enum class PVState {RUNNING, JUMPING, WALKING, EATING};
    
    PoleVaultingZombie(int x, int y);
    void Update() override;
    void OnCollideWithPlant(GameObject* plant) override;
    void ValidateEatingTarget(const GameList<pGameObject>& worldList) override;
    void ProbeForward(GameWorld* world) override;

private:
    PVState m_pvState;
    int m_timer;
};

#endif
