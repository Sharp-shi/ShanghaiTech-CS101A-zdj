#ifndef GAME_LIST_HPP__
#define GAME_LIST_HPP__

#include <memory>
#include <utility>

template<typename T>
class GameList {
private:
    struct Node {
        T data;
        Node* prev;
        Node* next;
        
        Node(const T& val) : data(val), prev(nullptr), next(nullptr) {}
        Node(T&& val) : data(std::move(val)), prev(nullptr), next(nullptr) {}
    };
    
    Node* head;
    Node* tail;
    size_t count;
    
public:
    class iterator {
    private:
        Node* current;
     
    public:
    iterator(Node* node) : current(node) {}
        
    T& operator*() { return current->data; }
    T* operator->() { return &(current->data); }
        
    iterator& operator++() {
        if (current) current = current->next;
        return *this;
    }

    iterator operator++(int) {
    iterator tmp = *this;
       ++(*this);
       return tmp;
    }
      
    bool operator==(const iterator& other) const {return current == other.current;}
   
    bool operator!=(const iterator& other) const {return current != other.current;}
        
    Node* getNode() const { return current; }

    };
    
    class const_iterator {
    private:
        const Node* current;
     
    public:
      const_iterator(const Node* node) : current(node) {}
        
    const T& operator*() const { return current->data; }
    const T* operator->() const { return &(current->data); }
        
    const_iterator& operator++() {
        if (current) current = current->next;
        return *this;
    }
        
    const_iterator operator++(int) {
        const_iterator tmp = *this;
        ++(*this);
        return tmp;
    }
        
    bool operator==(const const_iterator& other) const {return current == other.current;}
        
    bool operator!=(const const_iterator& other) const {return current != other.current;}
};
    GameList() : head(nullptr), tail(nullptr), count(0) {}
    
    ~GameList() {clear();}
    
    GameList(const GameList& other) : head(nullptr), tail(nullptr), count(0) {
        for (const auto& item : other) {
            push_back(item);
        }
    }
    
    GameList& operator=(const GameList& other) {
        if (this != &other) {
            clear();
            for (const auto& item : other) push_back(item);
        }
        return *this;
    }
    
    GameList(GameList&& other) noexcept 
        : head(other.head), tail(other.tail), count(other.count) {
        other.head = nullptr;
        other.tail = nullptr;
        other.count = 0;
    }
  
    GameList& operator=(GameList&& other) noexcept {
        if (this != &other) {
            clear();
            head = other.head;
            tail = other.tail;
            count = other.count;
            other.head = nullptr;
            other.tail = nullptr;
            other.count = 0;
        }
        return *this;
    }
    
    void push_back(const T& value) {
        Node* newNode = new Node(value);
        if (!tail) head = tail = newNode;
        else {
            tail->next = newNode;
            newNode->prev = tail;
            tail = newNode;
        }
        count++;
    }
    
    void push_back(T&& value) {
        Node* newNode = new Node(std::move(value));
        if (!tail) head = tail = newNode;
        else {
            tail->next = newNode;
            newNode->prev = tail;
            tail = newNode;
        }
        count++;
    }


  void push_front(const T& value) {
        Node* newNode = new Node(value);
        if (!head) head = tail = newNode;
        else {
            newNode->next = head;
            head->prev = newNode;
            head = newNode;
        }
        count++;
    }
    

    iterator erase(iterator pos) {
        Node* node = pos.getNode();
        if (!node) return end();
    
        Node* nextNode = node->next;
        
        if (node->prev) node->prev->next = node->next;
        else head = node->next;

        if (node->next) node->next->prev = node->prev;
        else tail = node->prev;
        delete node;
        count--;
        return iterator(nextNode);
    }

    void clear() {
        while (head) {
            Node* temp = head;
            head = head->next;
            delete temp;
        }
        tail = nullptr;
        count = 0;
    }
    
    bool empty() const {
        return count == 0;
    }
    
    size_t size() const {
        return count;
    }
    
    iterator begin() { return iterator(head); }
    iterator end() { return iterator(nullptr); }
    const_iterator begin() const { return const_iterator(head); }
    const_iterator end() const { return const_iterator(nullptr); }
};

#endif 
