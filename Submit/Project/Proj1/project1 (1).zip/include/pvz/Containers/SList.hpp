#pragma once
#include <cstddef>
#include <iterator>
#include <type_traits>
#include <utility>

namespace pvz {

template <class T>
class SList {
    //你的数据结构
};

} // namespace pvz
