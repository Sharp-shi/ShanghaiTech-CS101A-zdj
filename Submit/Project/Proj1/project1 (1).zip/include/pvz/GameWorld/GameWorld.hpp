#ifndef GAMEWORLD_HPP__
#define GAMEWORLD_HPP__

#include <memory>

#include "pvz/Framework/WorldBase.hpp"
#include "pvz/GameObject/GameObject.hpp"
#include "pvz/Framework/TextBase.hpp"
#include "pvz/utils.hpp"
#include "pvz/Containers/GameList.hpp"

using pGameWorld = std::shared_ptr<GameWorld>;
using pGameObject = std::shared_ptr<GameObject>;

class GameObject;

class GameWorld : public WorldBase, public std::enable_shared_from_this<GameWorld> {
public:
	GameWorld() = default;
	~GameWorld() = default;

	void Init() override;
	LevelStatus Update() override;
	void CleanUp() override;

	void Add(pGameObject obj) {
		mlist.push_back(obj);
	}

	void Remove(pGameObject obj);

	int GetSunCount() const { return m_SunCount; }
	void ChangeSun(int delta) { m_SunCount += delta; }

	int GetWaveCount() const { return m_WaveCount; }
	void ChangeWave(int delta = 1) { m_WaveCount += delta; }

	int GetNextZombieTick() const { return m_nextZombieTick; }
	void ChangeNextZombieTick(int delta = 1) { m_nextZombieTick += delta; }

	int GetSunDropCD() const { return m_SunDropCD; }
	void ChangeSunDropCD() { m_SunDropCD += 300; }

	void GenerateSun();

	void SetMouseState(mouse_state s) { m_mouseState = s; }
	mouse_state GetMouseState() const { return m_mouseState; }
	void SetSelectedSeed(ImageID id) { m_selectedSeed = id; }
	ImageID GetSelectedSeed() const { return m_selectedSeed; }

	bool IsZombieOnRowRight(int y, int x) const;
	void DamageZombiesInRadius(int cx, int cy, int radius, int damage);
	pGameObject GetPlantAtRect(int x, int y, int width, int height) const;

	const GameList<pGameObject>& GetObjectList() const { return mlist; }

private:
	GameList<pGameObject> mlist;
	int m_SunCount = 50;
	int m_WaveCount = 0;
	int m_nextZombieTick = 1200;
	int m_SunDropCD = 180;

	std::shared_ptr<class TextBase> m_sunText;
	std::shared_ptr<class TextBase> m_waveText;
	std::shared_ptr<class TextBase> m_resultText;

	mouse_state m_mouseState = mouse_state::M_NONE;
	ImageID m_selectedSeed = ImageID::NONE;
};

#endif 
