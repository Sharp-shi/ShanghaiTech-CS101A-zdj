#include "graph.hpp"
#include <queue>
#include <functional>

// 用于优先队列的堆节点
struct node {
  Graph::VertexID vertex;
  Graph::Weight dist;
  
  bool operator>(const node &other) const {
    return dist>other.dist;
  }
};

template <typename T>
using MinHeap=std::priority_queue<T,std::vector<T>,std::greater<T>>;

auto Graph::dijkstra(VertexID source) const -> std::vector<Weight> {
  // FIXME: This is a naive O(V^2) implementation. Overwrite it to make it run
  // within O(ElogV) time, which is more efficient when E = o(V^2/logV).
  std::vector<Weight> dist(numVertices(), infinity);
  MinHeap<node> heap;

  dist[source]=0;
  heap.push({.vertex=source,.dist=0});

  while(!heap.empty()){ 
    auto [current,d]=heap.top();
    heap.pop();

    if (d>dist[current]) continue;
    for(auto [to,weight]:mAdjacent[current]){
      if(dist[current]+weight<dist[to]){
        dist[to]=dist[current]+weight;
        heap.push({to,dist[to]});
      }
    }
  }
  return dist;
}

auto Graph::bellmanFord(VertexID source) const
    -> std::optional<std::vector<Weight>> {
  // TODO: Implement this.
  std::vector<Weight> dist(numVertices(),infinity);
  dist[source]=0;

  for(VertexID i=0;i+1<numVertices();++i){
    bool updated=false;
    for(VertexID u=0;u<numVertices();u++){
      if(dist[u]==infinity) continue;
      for(auto [v,weight]:mAdjacent[u]){
        if(dist[u]+weight<dist[v]){
          dist[v]=dist[u]+weight;
          updated=true;
        }
      }
    }
    if(!updated) return dist;
  }

  for(VertexID u=0;u<numVertices();u++){
    if(dist[u]==infinity) continue;
    for(auto [v,weight]:mAdjacent[u]){
      if(dist[u]+weight<dist[v]){
        return std::nullopt;
      }
    }
  }
  return dist;
}