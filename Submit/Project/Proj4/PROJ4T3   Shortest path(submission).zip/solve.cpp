#include <optional>
#include <cassert>

#include "problem.hpp"
#include "graph.hpp"

/// @brief Solve the given difference constraints problem.
/// @param problem 
/// @return The solution, or @c std::nullopt if the problem has no solutions.
std::optional<Problem::Solution> solve(const Problem &problem) {
  // TODO: Your code here.
  auto n=problem.getNumVars();

  if(n==0) return Problem::Solution{};

  const auto &constraints=problem.getConstraints();

  if(!problem.hasNegativeConstant()) return Problem::Solution(n,0);

  std::vector<Problem::Value> dist(n,0);

  for(Problem::VarID round=0;round<n;++round){
    bool updated=false;
    for(const auto &ct:constraints){
      if(dist[ct.var2]+ct.constant<dist[ct.var1]){
        if(round==n-1){
          return std::nullopt;
        }
        dist[ct.var1]=dist[ct.var2]+ct.constant;
        updated=true;
      }
    }
    if(!updated) break;
  }
  return dist;

}

int main() {
  Problem p1(5, {{0, 1, 0},
                 {0, 4, -1},
                 {1, 4, 1},
                 {2, 0, 5},
                 {3, 0, 4},
                 {3, 2, -1},
                 {4, 2, -3},
                 {4, 3, -3}});

  // This is a possible solution.
  assert(p1.isFeasible({-5, -3, 0, -1, -4}));

  auto sol = solve(p1);
  assert(sol);                        // The problem has a solution.
  assert(p1.isFeasible(sol.value())); // The solution is correct.

  return 0;
}